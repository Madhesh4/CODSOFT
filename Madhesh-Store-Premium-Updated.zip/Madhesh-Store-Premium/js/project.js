function addTask() {
  const input = document.getElementById('taskInput');
  const list = document.getElementById('taskList');
  if (!input || !list) return;
  const value = input.value.trim();
  if (!value) return;
  const li = document.createElement('li');
  li.className = 'card';
  li.style.padding = '16px 18px';
  li.innerHTML = '<strong>' + value + '</strong><p class="muted" style="margin-top:6px">Newly added task for project dashboard demo.</p>';
  list.prepend(li);
  input.value = '';
}
