const JOBS = [
  {
    title: 'Senior React Developer',
    company: 'TechFlow Inc',
    location: 'San Francisco, CA',
    mode: 'Remote',
    salary: '$140k - $180k',
    type: 'Full Time',
    experience: '5+ Years',
    posted: '2 days ago',
    skills: ['React', 'TypeScript', 'Next.js', 'APIs'],
    about: 'Build premium web interfaces, optimize frontend architecture and lead component systems across product squads.'
  },
  {
    title: 'Lead UX Designer',
    company: 'DesignCraft Studio',
    location: 'Remote',
    mode: 'Remote',
    salary: '$120k - $160k',
    type: 'Full Time',
    experience: '4+ Years',
    posted: '1 day ago',
    skills: ['Figma', 'Design Systems', 'Research', 'Prototyping'],
    about: 'Own end-to-end UX for premium digital products, lead design reviews and convert product ideas into clean, modern user journeys.'
  },
  {
    title: 'Data Scientist',
    company: 'NextData Labs',
    location: 'Bangalore',
    mode: 'Hybrid',
    salary: '$110k - $150k',
    type: 'Full Time',
    experience: '3+ Years',
    posted: '3 days ago',
    skills: ['Python', 'ML', 'Pandas', 'Experimentation'],
    about: 'Work on analytics pipelines, build predictive models and collaborate with product teams to turn data into business decisions.'
  }
];

function renderJobModal(index) {
  const job = JOBS[index];
  if (!job) return;
  document.getElementById('jobModalContent').innerHTML = `
    <span class="badge">${job.company}</span>
    <div class="detail-topline" style="margin-top:14px">
      <div>
        <h2>${job.title}</h2>
        <p class="muted" style="margin-top:8px">${job.location} • ${job.mode} • ${job.type}</p>
      </div>
      <div class="salary">${job.salary}</div>
    </div>
    <p class="muted" style="margin-top:18px">${job.about}</p>
    <div class="detail-specs">
      <div class="spec-box"><strong>Experience</strong><span>${job.experience}</span></div>
      <div class="spec-box"><strong>Posted</strong><span>${job.posted}</span></div>
      <div class="spec-box"><strong>Work Mode</strong><span>${job.mode}</span></div>
      <div class="spec-box"><strong>Role Type</strong><span>${job.type}</span></div>
    </div>
    <div class="muted-list">
      ${job.skills.map(skill => `<div>• ${skill}</div>`).join('')}
    </div>
    <div class="apply-row">
      <button class="btn btn-primary" type="button">Apply Now</button>
      <button class="btn btn-outline" type="button">Save Job</button>
    </div>`;
  document.getElementById('jobModal').classList.add('open');
}
function closeJobModal(){ document.getElementById('jobModal').classList.remove('open'); }

document.getElementById('jobGrid').addEventListener('click', e => {
  const btn = e.target.closest('[data-job]');
  if (!btn) return;
  renderJobModal(Number(btn.dataset.job));
});
document.getElementById('openFirstJob').addEventListener('click', () => renderJobModal(0));
document.getElementById('closeJobModal').addEventListener('click', closeJobModal);
document.getElementById('jobModal').addEventListener('click', e => { if (e.target.id === 'jobModal') closeJobModal(); });
