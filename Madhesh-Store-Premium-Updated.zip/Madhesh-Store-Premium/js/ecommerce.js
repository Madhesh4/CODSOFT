const ECOM_PRODUCTS = (() => {
  const baseProducts = [
    ['iPhone 15 Pro','Apple','phones',129999,139999,'18% OFF','128GB • Titanium • A17 Pro','iphone'],
    ['iPhone 15','Apple','phones',79999,89999,'11% OFF','128GB • Dynamic Island','iphone'],
    ['Samsung Galaxy S24 Ultra','Samsung','phones',124999,134999,'15% OFF','200MP • S Pen • AI Camera','phone'],
    ['Google Pixel 8 Pro','Google','phones',97999,109999,'12% OFF','Best Camera • AI Edit','phone'],
    ['OnePlus 12','OnePlus','phones',64999,74999,'13% OFF','Snapdragon Elite • 120Hz','phone'],
    ['Xiaomi 14','Xiaomi','phones',58999,67999,'14% OFF','Leica Camera • Fast Charge','phone'],
    ['Nothing Phone 2','Nothing','phones',41999,49999,'10% OFF','Glyph Interface • OLED','phone'],
    ['iPad Pro M4','Apple','tablets',99999,109999,'9% OFF','Ultra Retina XDR','tablet'],
    ['iPad Air','Apple','tablets',62999,69999,'8% OFF','M2 Chip • 11-inch','tablet'],
    ['Samsung Tab S9','Samsung','tablets',68999,78999,'17% OFF','AMOLED • Pen Included','tablet'],
    ['MacBook Air M3','Apple','laptops',114999,124999,'7% OFF','13-inch • All-day battery','laptop'],
    ['MacBook Pro M3 Pro','Apple','laptops',189999,204999,'6% OFF','Pro display • Creative Work','laptop'],
    ['Dell XPS 14','Dell','laptops',164999,174999,'5% OFF','OLED • Creator Class','laptop'],
    ['HP Spectre x360','HP','laptops',129999,144999,'10% OFF','2-in-1 • OLED Touch','laptop'],
    ['Lenovo Yoga Slim 7','Lenovo','laptops',94999,104999,'9% OFF','Slim premium ultrabook','laptop'],
    ['ASUS ROG Zephyrus','ASUS','laptops',154999,169999,'12% OFF','Gaming • RTX graphics','laptop'],
    ['AirPods Pro','Apple','audio',24999,27999,'10% OFF','ANC • Spatial Audio','earbuds'],
    ['Sony WH-1000XM5','Sony','audio',29999,34999,'14% OFF','Noise Cancelling • Studio sound','headphones'],
    ['Bose QuietComfort Ultra','Bose','audio',32999,36999,'11% OFF','Immersive Audio','headphones'],
    ['JBL Flip 6','JBL','audio',9999,11999,'16% OFF','Portable speaker • Bass boost','speaker'],
    ['Apple Watch Series 9','Apple','wearables',42999,47999,'10% OFF','Health • Calls • Fitness','watch'],
    ['Samsung Galaxy Watch 6','Samsung','wearables',25999,29999,'13% OFF','AMOLED • Sleep tracking','watch'],
    ['Garmin Forerunner 265','Garmin','wearables',41999,46999,'9% OFF','Runner focused GPS watch','watch'],
    ['Canon EOS R50','Canon','cameras',67999,75999,'12% OFF','Mirrorless • Creator kit','camera'],
    ['Sony ZV-E10','Sony','cameras',69999,79999,'13% OFF','Vlog camera • 4K','camera'],
    ['GoPro Hero 12','GoPro','cameras',35999,41999,'14% OFF','Action camera • Waterproof','camera'],
    ['PlayStation 5','Sony','gaming',54999,59999,'8% OFF','Ultra HD • Fast SSD','console'],
    ['Xbox Series X','Microsoft','gaming',52999,57999,'7% OFF','4K gaming • Quick Resume','console'],
    ['Nintendo Switch OLED','Nintendo','gaming',30999,34999,'11% OFF','Portable console • OLED','console'],
    ['DualSense Controller','Sony','gaming',6299,7299,'15% OFF','Adaptive triggers','controller'],
    ['Logitech MX Master 3S','Logitech','accessories',9999,11999,'17% OFF','Productivity mouse','mouse'],
    ['Keychron K8 Pro','Keychron','accessories',9999,12499,'20% OFF','Wireless mechanical keyboard','keyboard'],
    ['Samsung T7 SSD 1TB','Samsung','storage',8999,10999,'18% OFF','Portable SSD • USB-C','ssd'],
    ['SanDisk Extreme 1TB','SanDisk','storage',7999,9999,'16% OFF','High-speed portable storage','ssd'],
    ['Anker 737 Power Bank','Anker','accessories',10999,12999,'10% OFF','140W fast charging','powerbank'],
    ['Belkin 3-in-1 Charger','Belkin','accessories',12999,14999,'13% OFF','Wireless dock','charger'],
    ['Mi 33W SonicCharge','Xiaomi','accessories',1999,2599,'22% OFF','Phone fast charger','charger'],
    ['LG UltraWide Monitor','LG','monitors',27999,31999,'12% OFF','34-inch productivity display','monitor'],
    ['Samsung Odyssey G5','Samsung','monitors',24999,28999,'11% OFF','Gaming curved monitor','monitor'],
    ['BenQ PD2705U','BenQ','monitors',44999,51999,'14% OFF','Designer 4K monitor','monitor']
  ];

  const fillerNames = [
    ['Apple MagSafe Case','Apple','accessories',4499,5499,'18% OFF','Premium magnetic case','case'],
    ['Spigen Rugged Armor','Spigen','accessories',1499,1999,'25% OFF','Shock resistant case','case'],
    ['TP-Link Archer Router','TP-Link','network',5999,7299,'17% OFF','Wi-Fi 6 dual band','router'],
    ['Amazon Echo Dot','Amazon','smart-home',4499,5999,'25% OFF','Smart speaker with Alexa','speaker'],
    ['Philips Hue Starter Kit','Philips','smart-home',12999,14999,'13% OFF','Smart lights starter pack','bulb'],
    ['Dyson V12 Detect','Dyson','home',48999,54999,'11% OFF','Cordless vacuum cleaner','vacuum'],
    ['Kindle Paperwhite','Amazon','reading',13999,15999,'12% OFF','E-ink reading experience','kindle'],
    ['Noise Buds X','Noise','audio',2499,3299,'24% OFF','True wireless earbuds','earbuds'],
    ['Boat Rockerz 550','boAt','audio',1999,2999,'33% OFF','Affordable bass headphones','headphones'],
    ['Realme Pad 2','Realme','tablets',18999,22999,'17% OFF','Budget tablet','tablet']
  ];

  const products = [...baseProducts];
  let serial = 1;
  while (products.length < 100) {
    const src = fillerNames[(serial - 1) % fillerNames.length];
    const name = `${src[0]} ${serial}`;
    const price = src[3] + (serial % 7) * 350;
    const mrp = src[4] + (serial % 7) * 450;
    products.push([name, src[1], src[2], price, mrp, src[5], src[6], src[7]]);
    serial++;
  }

  return products.map((item, index) => ({
    id: index + 1,
    name: item[0],
    brand: item[1],
    category: item[2],
    price: item[3],
    mrp: item[4],
    offer: item[5],
    description: item[6],
    imageType: item[7],
    stock: (index % 9) + 2,
    rating: (4.2 + (index % 7) * 0.1).toFixed(1)
  }));
})();

const OFFER_FILTERS = ['All Offers', 'Big Saving', 'Apple Deals', 'Audio Deals', 'Budget Picks'];
const CATEGORY_LABELS = {
  all: 'All Categories', phones: 'Phones', tablets: 'Tablets', laptops: 'Laptops', audio: 'Audio', wearables: 'Wearables', cameras: 'Cameras', gaming: 'Gaming', accessories: 'Accessories', storage: 'Storage', monitors: 'Monitors', home: 'Home', 'smart-home':'Smart Home', network:'Network', reading:'Reading'
};

let currentOffer = 'All Offers';
let currentCategory = 'all';
let searchText = '';
let cart = JSON.parse(localStorage.getItem('madhesh_store_cart') || '[]');

function currency(value){ return `₹${value.toLocaleString('en-IN')}`; }
function mrpSave(product){ return Math.round(((product.mrp - product.price) / product.mrp) * 100); }
function imageEmoji(type){
  return {
    iphone:'📱', phone:'📱', tablet:'💻', laptop:'💻', earbuds:'🎧', headphones:'🎧', speaker:'🔊', watch:'⌚', camera:'📷', console:'🎮', controller:'🕹️', mouse:'🖱️', keyboard:'⌨️', ssd:'💾', powerbank:'🔋', charger:'🔌', monitor:'🖥️', case:'📱', router:'📶', bulb:'💡', vacuum:'🧹', kindle:'📚'
  }[type] || '✨';
}
function imagePalette(type){
  return {
    iphone:['#1d4ed8','#8b5cf6'], phone:['#0f766e','#2563eb'], tablet:['#0f172a','#3b82f6'], laptop:['#312e81','#2563eb'], earbuds:['#7c2d12','#ec4899'], headphones:['#4c1d95','#8b5cf6'], speaker:['#0f766e','#14b8a6'], watch:['#831843','#f43f5e'], camera:['#14532d','#22c55e'], console:['#111827','#4f46e5'], controller:['#1e293b','#0ea5e9'], mouse:['#1f2937','#8b5cf6'], keyboard:['#172554','#2563eb'], ssd:['#334155','#64748b'], powerbank:['#0f172a','#22c55e'], charger:['#451a03','#f59e0b'], monitor:['#0f172a','#06b6d4'], case:['#1e1b4b','#7c3aed'], router:['#0f172a','#06b6d4'], bulb:['#78350f','#fbbf24'], vacuum:['#0f172a','#14b8a6'], kindle:['#3f3f46','#52525b']
  }[type] || ['#1d4ed8','#8b5cf6'];
}
function productImage(product){
  const [c1,c2] = imagePalette(product.imageType);
  const emoji = imageEmoji(product.imageType);
  const safeName = product.name.replace(/&/g,'&amp;');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="${c1}"/><stop offset="1" stop-color="${c2}"/></linearGradient></defs><rect width="600" height="600" rx="40" fill="url(#g)"/><circle cx="490" cy="120" r="90" fill="rgba(255,255,255,0.15)"/><circle cx="120" cy="500" r="110" fill="rgba(255,255,255,0.12)"/><text x="300" y="230" text-anchor="middle" font-size="120">${emoji}</text><text x="300" y="330" text-anchor="middle" font-family="Arial, sans-serif" font-weight="700" font-size="36" fill="white">${safeName.slice(0,24)}</text><text x="300" y="382" text-anchor="middle" font-family="Arial, sans-serif" font-size="24" fill="rgba(255,255,255,0.9)">${product.brand} • ${CATEGORY_LABELS[product.category] || product.category}</text></svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

function hasOffer(product){
  if (currentOffer === 'All Offers') return true;
  if (currentOffer === 'Big Saving') return mrpSave(product) >= 15;
  if (currentOffer === 'Apple Deals') return product.brand === 'Apple';
  if (currentOffer === 'Audio Deals') return product.category === 'audio';
  if (currentOffer === 'Budget Picks') return product.price <= 10000;
  return true;
}

function getFilteredProducts(){
  return ECOM_PRODUCTS.filter(product => {
    const searchMatch = !searchText || `${product.name} ${product.brand} ${product.category}`.toLowerCase().includes(searchText.toLowerCase());
    const categoryMatch = currentCategory === 'all' || product.category === currentCategory;
    return searchMatch && categoryMatch && hasOffer(product);
  });
}

function renderOfferFilters(){
  const wrap = document.getElementById('offerFilters');
  wrap.innerHTML = OFFER_FILTERS.map(filter => `<button class="filter-chip ${filter===currentOffer?'active':''}" data-offer="${filter}">${filter}</button>`).join('');
}
function renderCategoryFilters(){
  const categories = ['all', ...new Set(ECOM_PRODUCTS.map(item => item.category))];
  const wrap = document.getElementById('categoryFilters');
  wrap.innerHTML = categories.map(cat => `<button class="filter-chip ${cat===currentCategory?'active':''}" data-category="${cat}">${CATEGORY_LABELS[cat] || cat}</button>`).join('');
}
function renderFeaturedOffers(){
  const cards = [
    {title:'Mega Offer Week', text:'Top phones, laptops and audio devices up to 25% off.', tag:'Limited'},
    {title:'Apple Special', text:'iPhone, MacBook, iPad and AirPods curated in one premium deal zone.', tag:'Apple'},
    {title:'Budget Picks', text:'Under ₹10,000 accessories, audio and storage products ready to grab.', tag:'Budget'}
  ];
  document.getElementById('featuredOffers').innerHTML = cards.map(card => `<div class="offer-card"><span class="badge">${card.tag}</span><h3>${card.title}</h3><p class="muted" style="margin-top:8px">${card.text}</p></div>`).join('');
  document.getElementById('heroOfferPreview').innerHTML = cards.map(card => `<div class="offer-pill">${card.tag}</div>`).join('');
}

function productCard(product){
  return `<article class="card reveal product-card">
    <div class="product-media"><img src="${productImage(product)}" alt="${product.name}" loading="lazy"></div>
    <div class="tag-row"><span class="offer-badge">${product.offer}</span><span class="stock-badge">${product.stock} left</span></div>
    <div class="product-meta">
      <div>
        <div class="product-brand">${product.brand}</div>
        <h3 style="margin-top:4px">${product.name}</h3>
      </div>
      <button class="link-btn" type="button" data-view="${product.id}">View</button>
    </div>
    <p class="muted">${product.description}</p>
    <p class="price">${currency(product.price)} <span class="strike">${currency(product.mrp)}</span></p>
    <div class="product-actions">
      <button class="btn btn-primary" type="button" data-add="${product.id}">Add to Cart</button>
      <button class="btn btn-outline" type="button" data-view="${product.id}">Quick View</button>
    </div>
  </article>`;
}

function renderProducts(){
  const filtered = getFilteredProducts();
  document.getElementById('productGrid').innerHTML = filtered.map(productCard).join('');
  document.getElementById('productCount').textContent = ECOM_PRODUCTS.length;
  document.getElementById('offerCount').textContent = ECOM_PRODUCTS.filter(p => mrpSave(p) >= 15).length;
}

function updateCartUI(){
  const count = cart.reduce((sum,item) => sum + item.qty, 0);
  const total = cart.reduce((sum,item) => sum + item.qty * item.price, 0);
  document.getElementById('cartCount').textContent = count;
  document.getElementById('cartBadge').textContent = count;
  document.getElementById('cartItemsCount').textContent = count;
  document.getElementById('cartTotal').textContent = currency(total);
  const wrap = document.getElementById('cartItems');
  if (!cart.length) {
    wrap.innerHTML = `<div class="empty-state">Cart la innum edhuvum illa da. Products la add pannina inga full ah paakalam.</div>`;
  } else {
    wrap.innerHTML = cart.map(item => `<div class="cart-item"><div class="cart-thumb"><img src="${productImage(item)}" alt="${item.name}"></div><div><h4>${item.name}</h4><p class="muted">${currency(item.price)}</p></div><div class="qty-pill">x${item.qty}</div></div>`).join('');
  }
  localStorage.setItem('madhesh_store_cart', JSON.stringify(cart));
}

function addToCartById(id){
  const product = ECOM_PRODUCTS.find(item => item.id === Number(id));
  if (!product) return;
  const existing = cart.find(item => item.id === product.id);
  if (existing) existing.qty += 1;
  else cart.push({ ...product, qty: 1 });
  updateCartUI();
  openCart();
}

function openCart(){ document.getElementById('cartDrawer').classList.add('open'); }
function closeCart(){ document.getElementById('cartDrawer').classList.remove('open'); }

function openProductModal(id){
  const product = ECOM_PRODUCTS.find(item => item.id === Number(id));
  if (!product) return;
  document.getElementById('productDetailContent').innerHTML = `
    <div class="detail-media"><img src="${productImage(product)}" alt="${product.name}"></div>
    <div>
      <span class="badge">${product.brand}</span>
      <h2 style="margin-top:14px">${product.name}</h2>
      <p class="muted" style="margin-top:10px">${product.description}</p>
      <div class="tag-row" style="margin-top:16px"><span class="offer-badge">${product.offer}</span><span class="stock-badge">Rating ${product.rating}</span></div>
      <p class="price" style="margin-top:18px">${currency(product.price)} <span class="strike">${currency(product.mrp)}</span></p>
      <div class="detail-specs">
        <div class="spec-box"><strong>Category</strong><span>${CATEGORY_LABELS[product.category] || product.category}</span></div>
        <div class="spec-box"><strong>Stock</strong><span>${product.stock} units</span></div>
        <div class="spec-box"><strong>You Save</strong><span>${mrpSave(product)}%</span></div>
        <div class="spec-box"><strong>Delivery</strong><span>1-3 days</span></div>
      </div>
      <div class="muted-list">
        <div>• Premium quality product card with direct cart action.</div>
        <div>• Offer and image preview original e-commerce feel ku add pannirukkom.</div>
        <div>• Search, category, offer filter ellam work aagum.</div>
      </div>
      <div class="apply-row"><button class="btn btn-primary" type="button" data-add="${product.id}">Add to Cart</button><button class="btn btn-outline" type="button" id="modalViewCart">View Cart</button></div>
    </div>`;
  document.getElementById('productModal').classList.add('open');
}
function closeProductModal(){ document.getElementById('productModal').classList.remove('open'); }

function bindEvents(){
  document.getElementById('offerFilters').addEventListener('click', e => {
    const btn = e.target.closest('[data-offer]');
    if (!btn) return;
    currentOffer = btn.dataset.offer;
    renderOfferFilters();
    renderProducts();
  });
  document.getElementById('categoryFilters').addEventListener('click', e => {
    const btn = e.target.closest('[data-category]');
    if (!btn) return;
    currentCategory = btn.dataset.category;
    renderCategoryFilters();
    renderProducts();
  });
  document.getElementById('searchInput').addEventListener('input', e => {
    searchText = e.target.value.trim();
    renderProducts();
  });
  document.getElementById('productGrid').addEventListener('click', e => {
    const addBtn = e.target.closest('[data-add]');
    const viewBtn = e.target.closest('[data-view]');
    if (addBtn) addToCartById(addBtn.dataset.add);
    if (viewBtn) openProductModal(viewBtn.dataset.view);
  });
  document.getElementById('productDetailContent').addEventListener('click', e => {
    const addBtn = e.target.closest('[data-add]');
    if (addBtn) addToCartById(addBtn.dataset.add);
    if (e.target.id === 'modalViewCart') { closeProductModal(); openCart(); }
  });
  document.getElementById('openCartBtn').addEventListener('click', openCart);
  document.getElementById('heroCartBtn').addEventListener('click', openCart);
  document.getElementById('closeCartBtn').addEventListener('click', closeCart);
  document.getElementById('closeProductModal').addEventListener('click', closeProductModal);
  document.getElementById('cartDrawer').addEventListener('click', e => { if (e.target.id === 'cartDrawer') closeCart(); });
  document.getElementById('productModal').addEventListener('click', e => { if (e.target.id === 'productModal') closeProductModal(); });
}

renderOfferFilters();
renderCategoryFilters();
renderFeaturedOffers();
renderProducts();
updateCartUI();
bindEvents();
