function checkAnswer(button, isCorrect) {
  const result = document.getElementById('quiz-result');
  document.querySelectorAll('.option-btn').forEach(btn => btn.style.borderColor = 'rgba(255,255,255,0.12)');
  button.style.borderColor = isCorrect ? 'rgba(34,197,94,1)' : 'rgba(239,68,68,1)';
  result.textContent = isCorrect ? 'Correct answer! Super da 🔥' : 'Wrong answer. Correct option is CSS.';
  result.style.color = isCorrect ? '#86efac' : '#fca5a5';
}
