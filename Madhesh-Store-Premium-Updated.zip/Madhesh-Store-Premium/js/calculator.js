const display = document.getElementById('display');
function appendValue(value) {
  if (!display) return;
  display.value += value;
}
function clearDisplay() {
  if (!display) return;
  display.value = '';
}
function deleteLast() {
  if (!display) return;
  display.value = display.value.slice(0, -1);
}
function calculateResult() {
  if (!display) return;
  try {
    display.value = Function('return ' + display.value)();
  } catch (error) {
    display.value = 'Error';
  }
}
